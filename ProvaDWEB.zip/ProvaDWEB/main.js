let cont = 0; 

function contador() {
    let nome = document.getElementById('nome').value;
    let tamanhoNome = nome.length;
    let textoInserir = document.getElementById('insereContador');

    if(cont <= tamanhoNome){
        textoInserir.innerText = nome + " -> " + cont++;
        console.log(cont)
    }
    setTimeout(contador, 15000);
}

function mostrarDataHora() {
    let data = new Date();
    let horas = data.getHours();
    let minutos = data.getMinutes();
    let segundos = data.getSeconds();


    horas = horas < 10 ? "0" + horas : horas;
    minutos = minutos < 10 ? "0" + minutos : minutos;
    segundos = segundos < 10 ? "0" + segundos : segundos;

    let dia = data.getDate();
    let mes = data.getMonth() + 1; 
    let ano = data.getFullYear();

    let dataFormatada = dia + "/" + mes + "/" + ano;

    let horaAtual = horas + ":" + minutos + ":" + segundos;

    document.getElementById('horaAtual').innerText = horaAtual;
    document.getElementById('dataAtual').innerText = dataFormatada;
}
setInterval(mostrarDataHora, 1000);
mostrarDataHora();

function conversor() {
    let celsius = document.getElementById('graus').value;
    let resultado = (celsius * (9 / 5) + 32);

    document.getElementById('resultado').innerText = resultado;
}

document.getElementById('calcular').onclick = conversor;

function link(){
    window.location.href = "https://www.sp.senai.br/";
}


