
let startTime;
let updatedTime;
let difference;
let tInterval;
let running = false;
let paused = false;

function startCronometro() {
    if (!running) {
        startTime = new Date().getTime();
        tInterval = setInterval(getShowTime, 1);
        running = true;
        paused = false;
    }
}

function pauseCronometro() {
    if (!paused && running) {
        clearInterval(tInterval);
        paused = true;
    } else if (paused) {
        running = false;
        startCronometro();
    }
}

function resetCronometro() {
    clearInterval(tInterval);
    running = false;
    paused = false;
    document.getElementById('horas').innerHTML = '00';
    document.getElementById('minuto').innerHTML = '00';
    document.getElementById('segundos').innerHTML = '00';
    document.getElementById('milisegundo').innerHTML = '000';
}

function getShowTime() {
    updatedTime = new Date().getTime();
    difference = updatedTime - startTime;

    let hours = Math.floor((difference % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
    let minutes = Math.floor((difference % (1000 * 60 * 60)) / (1000 * 60));
    let seconds = Math.floor((difference % (1000 * 60)) / 1000);
    let milliseconds = Math.floor((difference % 1000));

    document.getElementById('horas').innerHTML = pad(hours);
    document.getElementById('minuto').innerHTML = pad(minutes);
    document.getElementById('segundos').innerHTML = pad(seconds);
    document.getElementById('milisegundo').innerHTML = pad(milliseconds, 3);
}

function pad(number, digits = 2) {
    return number.toString().padStart(digits, '0');
} 
