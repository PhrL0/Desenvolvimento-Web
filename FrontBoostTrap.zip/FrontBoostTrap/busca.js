//Função para atualizar a data e hora no dropdown da navbar
function atualizaDataHora(){
    //Cria um novo objeto Date para obter a data e hora atuais
    const now = new Date();
    //Define as opções para formatar a data e hora em português
    const options = {
        weekday: 'long',//Dia da semana
        year: 'numeric',//Ano
        month:'long',//Mês
        day:'numeric',//Dia do mês
        hour:'2-digit',//Hora em formato de dois digitos
        minute:'2-digit',//Minuto em formato de dois digitos
        second:'2-digit'//Seundo em formato de dois digitos
    };
    //Atualiza o conteudo do elemento com o ID 'datetime' com a data e hora formatadas
    document.getElementById('datetime').textContent = now.toLocaleDateString('pt-BR', options);
}
//Atualiza a data e hora a cada segundo
setInterval(atualizaDataHora, 1000);
//Atualiza a data e hora imediatamente ao carregar a pagina
atualizaDataHora();

//Dados de exemplo dos contatos
const contatos = [
    {name: 'João Sila', email:'joao.silva@example.com', phone: '(11) 12345-6789'},
    {name: 'Pedro Henrique', email:'pedro.hen@example.com', phone: '(11) 12375-6389'},
    {name: 'José Alberto', email:'ze.alberto@example.com', phone: '(11) 15434-6899'},
    {name: 'Maria Oliveira', email:'maria.oliveira@example.com', phone: '(11) 78345-6439'}
];
//Função para exibir contatos na tabela
function displayContatos(filteredContacts){
    //Seleciona o corpo da tabela onde os contatos serão exibidos
    const tablebody = document.querySelector('#contactTable tbody');
    //lIMPA O CORPO DA TABELA ANTES DE ADICIONAR NOVOS RESULTADOS
    tablebody.innerHTML = '';

    //Verifica se há contatos filtrados
    if(filteredContacts.length > 0){
        //Adiciona uma linha para cada contato filtrado
        filteredContacts.forEach(contact =>{
            const row = document.createElement('tr');
            row.innerHTML = `
            <td>${contact.name}</td>
            <td>${contact.email}</td>
            <td>${contact.phone}</td>
            `;
            tablebody.appendChild(row);
        });
        console.log("Ola")
    } else{
        //Adiciona uma linha indicando que nenhum contato foi encontrado
        const row = document.createElement('tr');
        row.innerHTML = '<td colspan="3">Nenhum contato encontrado</td>';
        tablebody.appendChild(row);
        console.log("Errado")
    }
}
//Função para pesquisar contatos com base no texto digitado
function procuraContatos(){
    //obetem o valor do campo de pesquisa e converte para minusculas
    const query = document.getElementById('search').value.toLocaleLowerCase();
    //Filtra a lista de contatos para incluir apenas aqueles que correspondem a pesquisa
    const filteredContacts = contatos.filter(contact =>
        contact.name.toLowerCase().includes(query) ||
        contact.email.toLowerCase().includes(query) ||
        contact.phone.toLowerCase().includes(query) 
    );
    //Exibe os contatos filtrado na tabela
    displayContatos(filteredContacts);
}
//Adiciona um evento de clique ao botão de pesquisa
document.getElementById('searchButton').addEventListener('click',procuraContatos);

//Adciona um evento declique ao botao de limpar
document.getElementById('clearButton').addEventListener('click', function(){
    //limpa o campo de pesquisa
    document.getElementById('search').value = '';
    //limpa a tabela de contatos
    displayContatos([]);
});