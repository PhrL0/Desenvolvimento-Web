const lista_itens = {
    item1: "arroz",
    item2: "feijao",
    quantidade1: 2,
    quantidade2: 3,
    mostrar_itens: function() {
        alert("comprei " + lista_itens.quantidade1 + " pacotes de " + lista_itens.item2)
    }
}
lista_itens.mostrar_itens();
dateUsers = {
    nome: 'Pedro',
    idade: 20,
    endereco:'Avenida Doutor Jose Reali',
    nacionalidade: 'Brasileiro',
    outputDate:function (){
        alert('Nome: ' + dateUsers.nome + 
              ' Idade ' + dateUsers.idade + 
              ' Endereço: ' + dateUsers.endereco + 
              ' Nacionalidade: ' + dateUsers.nacionalidade)
    }
}
dateUsers.outputDate();

dateBook = {
    titulo: 'Assim falava Zaratustra',
    autor: 'Friederich Nietzsche',
    editora: 'Companhia de Bolso',
    anoEdicao: 2018,
    outputDate: function(){
        alert("Título: " + dateBook.titulo + 
              ' Autor: ' +  dateBook.autor + 
              ' Editora: ' + dateBook.editora + 
              ' Ano de edição: ' + dateBook.anoEdicao)
    }
}
dateBook.outputDate();
