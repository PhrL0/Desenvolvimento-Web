let listaDeItens = []  // Array

// BLOCO DE DECLARAÇÃO DAS CONSTANTES --------------------------------------------------
const form = document.getElementById("form-itens")
const itensInput = document.getElementById("receber-item")
const ulItens = document.getElementById("lista-de-itens")
const ulItensComprados = document.getElementById("itens-comprados")
const listaRecuperada = localStorage.getItem('listaDeItens')

// Final de bloco de declaração das constantes ----------------------------------------

//Função Local Storage ----------------------------------------------------------------
function atualizaLocalStorage () {
    localStorage.setItem('listaDeItens', JSON.stringify(listaDeItens))
}

if (listaRecuperada) {
    listaDeItens = JSON.parse(listaRecuperada)
    mostrarItem()
}
else {
    listaDeItens = []
}

// EVENTO DO BOTÃO  -------------------------------------------------------------------
form.addEventListener("submit",function(evento){
    evento.preventDefault();
    salvarItem()
    mostrarItem()
    itensInput.focus()
})//Final do Evendo do Botão ------------------------------------------------------------


// FUNÇÃO PARA SALVAR ITEM-- ----------------------------------------------------------
function salvarItem(){
    const comprasItem = itensInput.value
    const checaDuplicado = listaDeItens.some((elemento)=>elemento.valor.toUpperCase() === comprasItem.toUpperCase())
    if(checaDuplicado){
        alert("Elemento já existe")
    }
    else{
        listaDeItens.push({
            valor: comprasItem,
            checar: false
        })
    }
    //console.log(listaDeItens)
    itensInput.value = ''
}// final da função para salvar item ---------------------------------------------------


//  FUNÇÃO PARA MOSTRAR ITEM ----------------------------------------------------------
function mostrarItem(){
    ulItens.innerHTML = ''
    ulItensComprados.innerHTML = ''
    listaDeItens.forEach((elemento,index)=>{
        if (elemento.checar) { 
            ulItensComprados.innerHTML +=`
            <li class="item-compra is-flex is-justify-content-space-between" data-value="${index}">
                <div>
                    <input type="checkbox" class="is-clickable" />
                    <input type="text" class="is-size-5" value="${elemento.valor}"></input>
                </div>
                <div>
                    <i class="fa-solid fa-trash is-clickable deletar"></i>
                    
                </div>
            </li>
            `
        }
        else {
            ulItens.innerHTML +=`
            <li class="item-compra is-flex is-justify-content-space-between" data-value="${index}">
                <div>
                    <input type="checkbox" class="is-clickable" />
                    <input type="text" class="is-size-5" value="${elemento.valor}"></input>
                </div>
                <div>
                    <i class="fa-solid fa-trash is-clickable deletar"></i>
                    
                </div>
            </li>
        `
        }
        })

        const inputsCheck = document.querySelectorAll('input[type="checkbox"]')
        inputsCheck.forEach(i => {
            i.addEventListener('click', (evento) => {
                const valorDoElemento = evento.target.parentElement.parentElement.getAttribute('data-value')
                listaDeItens[valorDoElemento].checar = evento.target.checked
                console.log(listaDeItens[valorDoElemento].checar)
                mostrarItem()
                atualizaLocalStorage()
            })
        })

        const deletarObjetos = document.querySelectorAll(".deletar")
        deletarObjetos.forEach(i => {
            i.addEventListener('click', (evento) => {
                valorDoElemento = evento.target.parentElement.parentElement.getAttribute('data-value')
                listaDeItens.splice(valorDoElemento, 1)
                mostrarItem()
                atualizaLocalStorage()

       
            })
    })// Final da função para mostrar item -------------------------------------------------
}