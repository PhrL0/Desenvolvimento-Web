
setInterval(() =>{
    LerNodeRedJson()
    LerNodeRedObj()

},/*5000*/)
let desenho = document.querySelector(".desenho");
let svgNS = 'http://www.w3.org/2000/svg';

let Mlinha = document.createElementNS(svgNS,'line');
function LerNodeRedJson(){
    const valor = new XMLHttpRequest(); // constructor
    valor.open('GET','http://10.110.6.137:9097/dadosn1')
    valor.send()
    valor.onload = function(){
        let txt = JSON.stringify(this.responseText) // converte em formato json
        document.getElementById("texto2").innerHTML = txt // coloca o valor json na pagina
    }
}

function LerNodeRedObj(){
    const valor = new XMLHttpRequest(); // constructor
    valor.open('GET','http://10.110.6.137:9097/dadosn1')
    valor.send()
    valor.onload = function(){
        let obj = JSON.parse(this.responseText) // converte em formato json
        let contador = obj.contador //pega o valor do rotulo contador
        document.getElementById("texto").innerHTML = contador // coloca o valor json na pagina
        Mlinha.setAttributeNS(null,"x1",1)
        Mlinha.setAttributeNS(null,"y1",10)
        Mlinha.setAttributeNS(null,"x2",contador)
        Mlinha.setAttributeNS(null,"y2",10)
        Mlinha.setAttributeNS(null, "style","stroke:blue; stroke-width:5")
        desenho.appendChild(Mlinha)
    }
}

