package Screen;

import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;
import java.awt.Font;

public class Principal extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField txt1;
	private JTextField txt2;

	String valores = "";
	String sinal = "";
	double valor = 0;
	double valor2 = 0;
	double result = 0;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Principal frame = new Principal();
					frame.setVisible(true);
					frame.setLocationRelativeTo(null);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	public void insere(String x) {
		if (valores.length() < 10) {
			valores = valores.concat(x);
			txt1.setText(valores);
			}
	}

	public void jogaTela(String x) {
		switch (x) {
		case "+":
			txt2.setText(txt1.getText());
			valores = "";
			txt1.setText("");
			break;
		case "-":
			txt2.setText(txt1.getText());
			valores = "";
			txt1.setText("");
			break;
		case "/":
			txt2.setText(txt1.getText());
			valores = "";
			txt1.setText("");
			break;
		case "x":
			txt2.setText(txt1.getText());
			valores = "";
			txt1.setText("");
			break;
			}
		}
	/**
	 * Create the frame.
	 */
	public Principal() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 580, 753);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);

		JButton bot1 = new JButton("1");
		bot1.setFont(new Font("Tahoma", Font.PLAIN, 20));
		
		bot1.setBounds(10, 496, 91, 91);
		contentPane.add(bot1);

		JButton bot4 = new JButton("4");
		bot4.setFont(new Font("Tahoma", Font.PLAIN, 20));
		
		bot4.setBounds(10, 394, 91, 91);
		contentPane.add(bot4);

		JButton bot7 = new JButton("7");
		bot7.setFont(new Font("Tahoma", Font.PLAIN, 20));
		
		bot7.setBounds(10, 292, 91, 91);
		contentPane.add(bot7);

		JButton bot2 = new JButton("2");
		bot2.setFont(new Font("Tahoma", Font.PLAIN, 20));
	
		bot2.setBounds(111, 496, 91, 91);
		contentPane.add(bot2);

		JButton bot5 = new JButton("5");
		bot5.setFont(new Font("Tahoma", Font.PLAIN, 20));
		
		bot5.setBounds(111, 394, 91, 91);
		contentPane.add(bot5);

		JButton bot8 = new JButton("8");
		bot8.setFont(new Font("Tahoma", Font.PLAIN, 20));
		
		bot8.setBounds(111, 292, 91, 91);
		contentPane.add(bot8);

		JButton bot9 = new JButton("9");
		bot9.setFont(new Font("Tahoma", Font.PLAIN, 20));
		
		bot9.setBounds(212, 292, 91, 91);
		contentPane.add(bot9);

		JButton bot6 = new JButton("6");
		bot6.setFont(new Font("Tahoma", Font.PLAIN, 20));
		
		bot6.setBounds(212, 394, 91, 91);
		contentPane.add(bot6);

		JButton bot3 = new JButton("3");
		bot3.setFont(new Font("Tahoma", Font.PLAIN, 20));
		
		bot3.setBounds(212, 496, 91, 91);
		contentPane.add(bot3);

		JButton bot0 = new JButton("0");
		bot0.setFont(new Font("Tahoma", Font.PLAIN, 20));
		
		bot0.setBounds(10, 598, 192, 91);
		contentPane.add(bot0);

		JButton ponto = new JButton(".");
		ponto.setFont(new Font("Tahoma", Font.PLAIN, 20));
		ponto.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				insere(".");
				
			}
		});
		ponto.setBounds(212, 598, 91, 91);
		contentPane.add(ponto);

		JButton botCE = new JButton("CE");
		botCE.setFont(new Font("Tahoma", Font.PLAIN, 20));
		
		botCE.setBounds(313, 292, 91, 91);
		contentPane.add(botCE);

		JButton divide = new JButton("/");
		divide.setFont(new Font("Tahoma", Font.PLAIN, 20));
		
		divide.setBounds(313, 394, 91, 91);
		contentPane.add(divide);

		JButton menos = new JButton("-");
		menos.setFont(new Font("Tahoma", Font.PLAIN, 20));
		menos.setBounds(313, 496, 91, 91);
		contentPane.add(menos);

		JButton igual = new JButton("=");
		igual.setFont(new Font("Tahoma", Font.PLAIN, 20));
		igual.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				switch (sinal) {
				case "+":
					valor = Double.parseDouble(txt2.getText());
					valor2 = Double.parseDouble(txt1.getText());
					result = valor + valor2;
					txt1.setText("" + result);
					break;
				case "-":
					valor = Double.parseDouble(txt2.getText());
					valor2 = Double.parseDouble(txt1.getText());
					result = valor - valor2;
					txt1.setText("" + result);
					break;
				case "/":
					valor = Double.parseDouble(txt2.getText());
					valor2 = Double.parseDouble(txt1.getText());
					result = valor / valor2;
					txt1.setText("" + result);
					break;
				case "x":
					valor = Double.parseDouble(txt2.getText());
					valor2 = Double.parseDouble(txt1.getText());
					result = valor * valor2;
					txt1.setText("" + result);
					break;
				}
			}
		});
		igual.setBounds(313, 598, 91, 91);
		contentPane.add(igual);

		JButton botC = new JButton("C");
		botC.setFont(new Font("Tahoma", Font.PLAIN, 20));
		botC.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				txt1.setText("");
				valores = "";
			}
		});
		botC.setBounds(434, 292, 91, 91);
		contentPane.add(botC);

		JButton mulitplica = new JButton("x");
		mulitplica.setFont(new Font("Tahoma", Font.PLAIN, 20));
		
		mulitplica.setBounds(434, 394, 91, 91);
		contentPane.add(mulitplica);

		JButton mais = new JButton("+");
		mais.setFont(new Font("Tahoma", Font.PLAIN, 20));
		
		mais.setBounds(434, 496, 91, 193);
		contentPane.add(mais);

		txt1 = new JTextField();
		txt1.setEditable(false);
		txt1.setFont(new Font("Tahoma", Font.PLAIN, 20));
		txt1.setBounds(10, 35, 551, 125);
		contentPane.add(txt1);
		txt1.setColumns(10);

		txt2 = new JTextField();
		txt2.setEditable(false);
		txt2.setFont(new Font("Tahoma", Font.PLAIN, 20));
		txt2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		txt2.setBounds(10, 213, 293, 50);
		contentPane.add(txt2);
		txt2.setColumns(10);
		
		bot1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				insere("1");
			}
		});
		
		bot4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				insere("4");
			}
		});
		
		bot7.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				insere("7");
			}
		});
		
		bot5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				insere("5");
			}
		});
		
		bot2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				insere("2");
			}
		});
		
		bot8.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				insere("8");
			}
		});
		
		bot9.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				insere("9");

			}
		});
		
		bot6.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				insere("6");
			}
		});
		
		bot3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				insere("3");
			}
		});
		
		bot0.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				insere("0");
			}
		});
		
		menos.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				sinal = "-";
				jogaTela(sinal);
				mais.setEnabled(false);
				divide.setEnabled(false);
				mulitplica.setEnabled(false);
				menos.setEnabled(false);
				ponto.setEnabled(false);
			}
		});
		mais.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				sinal = "+";
				jogaTela(sinal);
				menos.setEnabled(false);
				divide.setEnabled(false);
				mulitplica.setEnabled(false);
				mais.setEnabled(false);
				ponto.setEnabled(false);
				
			}
		});
		mulitplica.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				sinal = "x";
				jogaTela(sinal);
				menos.setEnabled(false);
				divide.setEnabled(false);
				mais.setEnabled(false);
				mulitplica.setEnabled(false);
				ponto.setEnabled(false);
			}
		});
		divide.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				sinal = "/";
				jogaTela(sinal);
				menos.setEnabled(false);
				mulitplica.setEnabled(false);
				mais.setEnabled(false);
				divide.setEnabled(false);
				ponto.setEnabled(false);
			}
		});
		botCE.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				txt1.setText("");
				txt2.setText("");
				valores = "";
				mais.setEnabled(true);
				divide.setEnabled(true);
				mulitplica.setEnabled(true);
				menos.setEnabled(true);
				ponto.setEnabled(true);
			}
		});
	}
	
}
