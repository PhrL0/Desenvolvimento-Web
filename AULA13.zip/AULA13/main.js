let hh = document.getElementById("hh");
let mm = document.getElementById("mm");
let ss = document.getElementById("ss");

let h12 = document.getElementById("12h");
let h24 = document.getElementById("24h");

setInterval(() =>{
    relogio()
},)
   


function relogio(){
    let h = new Date().getHours()
    let m = new Date().getMinutes()
    let s = new Date().getSeconds()

    if(h12.checked){
        h24.checked = false
        if(h > 12){
            h = h -12
        }
        hh.style.strokeDashoffset = 440 - (440 * h) / 12;
    }
    else if(h24.checked){
        hh.style.strokeDashoffset = 440 - (440 * h) / 24;
    }

    h = (h < 10) ? '0' + h : h
    m = (m < 10) ? '0' + m : m
    s = (s < 10) ? '0' + s : s

    horas.innerHTML = h + '<br><span>Horas</span>';
    minutos.innerHTML = m + '<br><span>Minutos</span>';
    segundos.innerHTML = s + '<br><span>Segundos</span>'

    mm.style.strokeDashoffset = 440 - (440 * m) / 60;
    ss.style.strokeDashoffset = 440 - (440 * s) / 60;

}