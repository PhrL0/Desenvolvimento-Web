function soma(){
    let n1 = parseInt(document.getElementById('n1').value);
    let n2 = parseInt(document.getElementById('n2').value);
    let res = n1 + n2;
    document.getElementById('res').innerHTML=res;
}
function sub(){
    let n1 = parseInt(document.getElementById('n1').value);
    let n2 = parseInt(document.getElementById('n2').value);
    let res = n1 - n2;
    document.getElementById('res').innerHTML=res;
}

