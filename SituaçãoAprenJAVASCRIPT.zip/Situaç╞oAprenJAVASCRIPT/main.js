let listaDeItens = []  // Array

// BLOCO DE DECLARAÇÃO DAS CONSTANTES --------------------------------------------------
const form = document.getElementById("form-itens")
const itensInput = document.getElementById("receber-item")
const ulItens = document.getElementById("lista-de-itens")
const ulItensComprados = document.getElementById("itens-comprados")
const listaRecuperada = localStorage.getItem('listaDeItens')
const ulSituacao = document.getElementById("situacao-item")

// Final de bloco de declaração das constantes ----------------------------------------

//Função Local Storage ----------------------------------------------------------------
function atualizaLocalStorage () {
    localStorage.setItem('listaDeItens', JSON.stringify(listaDeItens))
}

if (listaRecuperada) {
    listaDeItens = JSON.parse(listaRecuperada)
    mostrarItem()
}
else {
    listaDeItens = []
}

// EVENTO DO BOTÃO  -------------------------------------------------------------------
form.addEventListener("submit",function(evento){
    evento.preventDefault();
    salvarItem()
    mostrarItem()
    itensInput.focus()
})//Final do Evendo do Botão ------------------------------------------------------------


// FUNÇÃO PARA SALVAR ITEM ----------------------------------------------------------
function salvarItem(){
    const comprasItem = itensInput.value
    const situacaoItem = ulSituacao.value // Obtém a situação do item do select
    const checaDuplicado = listaDeItens.some((elemento)=>elemento.valor.toUpperCase() === comprasItem.toUpperCase())
    if(checaDuplicado){
        alert("Elemento já existe")
    }
    else{
        listaDeItens.push({
            valor: comprasItem,
            situacao: situacaoItem, // Adiciona a situação do item
            checar: false
        })
        mostrarItem() // Atualiza a exibição dos itens após adicionar um novo
    }
    itensInput.value = ''
}// final da função para salvar item ---------------------------------------------------

// Função para mostrar os itens na página
function mostrarItem() {
    ulItens.innerHTML = '';
    ulItensComprados.innerHTML = '';

    listaDeItens.forEach((elemento, index) => {
        const itemTexto = `${elemento.valor} - ${elemento.situacao}`;
        const itemLista = `
            <li class="item-compra is-flex is-justify-content-space-between flex" data-value="${index}">
                <div class="caixa">
                    <input type="checkbox" class="checkbox-item" data-index="${index}" ${elemento.checar ? 'checked' : ''}>
                    <input type="text" class="is-size-5 ${elemento.checar ? 'riscado' : ''}" value="${itemTexto}">
                    <i class="delete" data-index="${index}">🗑️</i>
                </div>
            </li>
        `;

        if (elemento.checar) {
            ulItensComprados.innerHTML += itemLista;
        } else {
            ulItens.innerHTML += itemLista;
        }
    });

    const checkboxes = document.querySelectorAll('.checkbox-item');
    checkboxes.forEach((checkbox, index) => {
        checkbox.addEventListener('change', function () {
            listaDeItens[index].checar = this.checked; // Atualiza o estado do checkbox na lista de itens
            const item = ulItens.querySelector(`[data-value="${index}"]`);
            if (this.checked && item) {
                item.querySelector('input[type="text"]').classList.add('riscado'); // Adiciona classe para riscar o texto
                ulItensComprados.appendChild(item); // Move o item para a lista "Itens Cadastrados"
            } else if (!this.checked && item) {
                item.querySelector('input[type="text"]').classList.remove('riscado'); // Remove classe para riscar o texto
                ulItens.appendChild(item); // Move o item de volta para a lista "Itens a Comprar"
            }
            atualizaLocalStorage(); // Atualiza o armazenamento local
        });
    });

    const deleteIcons = document.querySelectorAll('.delete');
    deleteIcons.forEach((icon) => {
        icon.addEventListener('click', function () {
            const index = this.getAttribute('data-index');
            listaDeItens.splice(index, 1); // Remove o item da lista
            mostrarItem(); // Atualiza a exibição dos itens
            atualizaLocalStorage(); // Atualizar o armazenamento local
        });
    });
}

// Carregar os itens do armazenamento local ao carregar a página
if (listaRecuperada) {
    listaDeItens = JSON.parse(listaRecuperada);
}
mostrarItem();

